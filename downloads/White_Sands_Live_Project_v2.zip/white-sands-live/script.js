// script.js — Accessible, timed research presentation with manual exploration and reduced-motion safeguards.
const scenes = [...document.querySelectorAll('.scene')];
const toggle = document.querySelector('#toggle');
const restart = document.querySelector('#restart');
const explore = document.querySelector('#explore');
const progress = document.querySelector('#progress');
const status = document.querySelector('#mode-status');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const holds = scenes.map(scene => Number(scene.dataset.hold) || 14000);
const total = holds.reduce((a,b)=>a+b,0);
let playing = !reduced.matches, manual = false, index = 0, elapsed = 0, last = 0;
function updateControls() {
  toggle.textContent = playing ? 'Pause' : 'Play';
  toggle.setAttribute('aria-label', playing ? 'Pause presentation' : 'Play presentation');
  explore.setAttribute('aria-pressed', String(manual));
  explore.textContent = manual ? 'Watch' : 'Explore';
  status.textContent = manual ? 'Manual exploration enabled' : playing ? 'Automatic playback enabled' : 'Presentation paused';
}
function navigate(i) {
  index = (i + scenes.length) % scenes.length;
  elapsed = 0;
  scenes[index].scrollIntoView({behavior: reduced.matches ? 'instant' : 'smooth', block:'start'});
}
function setPlaying(value) {
  playing = Boolean(value) && !reduced.matches;
  if(playing) manual = false;
  last = 0;
  updateControls();
}
toggle.addEventListener('click', () => setPlaying(!playing));
restart.addEventListener('click', () => { navigate(0); setPlaying(!reduced.matches); });
explore.addEventListener('click', () => { manual = !manual; setPlaying(!manual && !reduced.matches); manual = !playing; updateControls(); });
reduced.addEventListener('change', () => { if(reduced.matches) {manual=true; setPlaying(false);} updateControls(); });
document.addEventListener('visibilitychange', () => {last=0;});
document.addEventListener('keydown', event => {
  if(event.target.closest('button,a,input,textarea')) return;
  if(event.code==='Space'){event.preventDefault();setPlaying(!playing);}
  if(event.key==='ArrowRight' || event.key==='PageDown'){event.preventDefault();manual=true;setPlaying(false);navigate(index+1);}
  if(event.key==='ArrowLeft' || event.key==='PageUp'){event.preventDefault();manual=true;setPlaying(false);navigate(index-1);}
});
let scrollTimer;
window.addEventListener('wheel', () => {if(playing){manual=true;setPlaying(false);}},{passive:true});
window.addEventListener('touchstart', () => {if(playing){manual=true;setPlaying(false);}},{passive:true});
function tick(now) {
  if(!last) last=now;
  const delta=Math.min(now-last,100);
  last=now;
  if(playing){
    elapsed+=delta;
    if(elapsed>=holds[index]) navigate(index+1);
    const past=holds.slice(0,index).reduce((a,b)=>a+b,0);
    progress.style.width=`${100*(past+elapsed)/total}%`;
    const photo=scenes[index].querySelector('.photo');
    if(photo && !reduced.matches) photo.style.setProperty('--shift',`${(elapsed/holds[index]-.5)*32}px`);
  }
  requestAnimationFrame(tick);
}
updateControls();
requestAnimationFrame(tick);
